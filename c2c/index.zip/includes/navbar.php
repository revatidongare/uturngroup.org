<header>
		<a id="logo" href="index.php"><img src="img/logo1.png" width="8%" alt="UturnGroup" data-retina="true"></a>
		<nav id="top-nav">
			<ul>
            	<!-- <li><a href="#search"><i class=" icon-search"></i></a></li> -->
				<li><a href="tour.html">Tour</a></li>
                <!-- <li><a href="#" data-toggle="modal" data-target="#login">Login</a></li> -->
			</ul>
		</nav>
		<a id="menu-trigger" href="#"><span class="menu-trigger-text">Menu</span><span class="menu-trigger-icon"></span></a>
	</header> <!-- End Header -->
    
    <nav id="side-nav">
		<ul class="side-nav-menu">    
         <li class="item-has-children">
				<a href="index.php">Home</a>
				<!-- <ul class="sub-menu">
					<li><a href="index.php">Home Layer slider</a></li>
                    <li><a href="index_2.html">Home Video</a></li>
					<li><a href="index_3.html">Home version 2</a></li>
                    <li><a href="index_4.html">Home version 3</a></li>
                    <li><a href="index_5.html">Home quick contact</a></li>
				</ul> -->
			</li> <!-- item-has-children -->        
           <!--  <li class="item-has-children">
				<a href="#">Academics</a>
				<ul class="sub-menu">
					<li><a href="diploma.html">Diploma courses</a></li>
                    <li><a href="graduate.html">Graduate courses</a></li>
					<li><a href="master.html">Master courses</a></li>
                    <li><a href="apply_online.html">Apply online</a></li>
                    <li><a href="staff.html">Staff</a></li>
				</ul>
			</li> --> <!-- item-has-children -->
			<li class="item-has-children">
				<a href="#">About</a>
				<ul class="sub-menu">
					<li><a href="about.html">About us</a></li>
                    <li><a href="contacts.html">Plan a visit</a></li>
					<!-- <li><a href="staff.html">Staff</a></li> -->
					<li><a href="gallery.html">Gallery</a></li>
				</ul>
			</li> <!-- item-has-children -->
            <li>
            <!-- <li class="item-has-children">
				<a href="#">Elements &amp; pages</a>
				<ul class="sub-menu">
					<li><a href="icon-pack-1.html">Icon pack 1</a></li>
					<li><a href="icon-pack-2.html">Icon pack 2</a></li>
					<li><a href="icon-pack-3.html">Icon pack 3</a></li>
                    <li><a href="icon-pack-4.html">Icon pack 4</a></li>
                    <li><a href="agenda_calendar.html">Agenda calendar</a></li>
                    <li><a href="shortcodes.html">Shortcodes</a></li>
                    <li><a href="site_launch/index.php">Site launch/Coming soon</a></li>
				</ul>
			</li> --> <!-- item-has-children -->
            <li>
            <ul class="side-nav-menu single-item-wp">
                <li><a href="tour.html">Tour</a></li>
                <li><a href="blog.html">Blog</a></li>
                <li><a href="contacts.html">Contacts</a></li>
            </ul> <!--single-item-wp -->
            <ul class="side-nav-menu single-item-wp">
                <!-- <li><a href="#" data-toggle="modal" data-target="#login">Login</a></li> -->
                <!-- <li><a href="#"  data-toggle="modal" data-target="#register">Register</a></li> -->
                <!-- <li class="hidden-lg hidden-md"><a href="#search">Search</a></li> -->
                <li><a href="#0">Terms &amp; Conditions</a></li>
            </ul> <!--single-item-wp -->
            </li>
        </ul> <!-- side-nav-menu -->
		<div id="social">
            <ul>
               <li><a href="#"><i class="icon-facebook"></i></a></li>
               <li><a href="#"><i class="icon-twitter"></i></a></li>
               <li><a href="#"><i class="icon-google"></i></a></li>
               <li><a href="#"><i class="icon-linkedin"></i></a></li>
           </ul>
       </div>
	</nav><!--End nav-->